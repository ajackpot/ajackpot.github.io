# Trineutron 대국 벤치마크 도구

이 디렉터리는 `trineutron/othello` 엔진을 외부 기준 엔진으로 삼아, 현재 앱 엔진의 실전 대국력을 비교하는 도구입니다.

## 왜 필요한가

노드 수, 탐색 시간, holdout MAE만으로는 실제 대국력 상승을 온전히 판단하기 어렵습니다.
이 도구는 다음을 보완합니다.

- **실전 결과**: 승/패/무와 평균 기보 마진으로 비교
- **색상 공정성**: 같은 시작 국면에서 **흑/백을 바꿔 두 번** 대국
- **opening book 편향 완화**: 기본값으로 `opening-plies=20`을 사용하여, 우리 엔진의 opening book 직접 사용 구간(12수)과 advisory 구간(18수)을 지난 뒤 중반부터 비교
- **종반 노이즈 제거**: 기본값으로 `empties <= 14`가 되면 trineutron을 더 두지 않고, **우리 exact solver를 한 번만 호출**해 승패를 판정
- **학습 전/후 비교**: 기본값으로 현재 generated profile+learned move-ordering(`active`), learned evaluator만 적용한 비교군(`phase-only`), 학습 전 seed evaluator(`legacy`)를 함께 돌려 비교

## 포함된 것

- `opponents/trineutron-engine.mjs`
  - upstream `trineutron/othello` 브라우저 엔진을 Node에서 호출할 수 있도록 옮긴 어댑터입니다.
  - 원본 UI는 사람이 항상 흑, AI가 항상 백인 구조인데, 어댑터에서는 **흑/백 어느 쪽도 플레이 가능**하게 만들었습니다.
- `benchmark-vs-trineutron.mjs`
  - opening suite 생성, 흑/백 대칭 매치, solver adjudication, JSON 저장을 수행합니다.
- `benchmark-vs-trineutron.bat`
  - Windows용 실행 래퍼입니다.
- `../../third_party/trineutron-othello/`
  - upstream 원본 `scripts/main.js`와 MIT 라이선스 사본입니다.

## 빠른 실행 예시

```bat
tools\engine-match\benchmark-vs-trineutron.bat benchmarks\stage31_vs_trineutron_solver_cutoff.json
```

기본값:

- variants: `active,phase-only,legacy`
- games: `4` openings (`총 8판/variant`)
- opening-plies: `20`
- our-time-ms: `100`
- their-time-ms: `100`
- our-max-depth: `6`
- their-max-depth: `18`
- exact-endgame-empties: `10`
- solver-adjudication-empties: `14`
- solver-adjudication-time-ms: `60000`
- their-noise-scale: `4`

## 직접 파라미터를 주는 예시

```bat
node tools/engine-match/benchmark-vs-trineutron.mjs ^
  --output-json benchmarks\stage31_vs_trineutron_8openings.json ^
  --variants active,phase-only,legacy ^
  --games 8 ^
  --opening-plies 20 ^
  --seed 11 ^
  --our-time-ms 150 ^
  --their-time-ms 150 ^
  --our-max-depth 6 ^
  --their-max-depth 18 ^
  --exact-endgame-empties 10 ^
  --solver-adjudication-empties 14 ^
  --solver-adjudication-time-ms 60000 ^
  --their-noise-scale 4
```

## 해석 팁

- `active`는 현재 `learned-eval-profile.generated.js`에 들어 있는 generated evaluator와 learned move-ordering profile을 모두 사용합니다.
- `phase-only`는 같은 learned evaluator를 쓰되, learned move-ordering slot은 비워 둔 비교군입니다.
- `legacy`는 학습 전 기본 seed evaluator(`legacy-seed-bucketed-v1`)와 late ordering 기본값으로 비교합니다.
- `solver-adjudication-empties=14`라면 빈칸이 14개 이하가 되는 순간, 그 이후 기보는 실제로 두지 않고 exact score만 계산합니다.
- 따라서 `averagePlayedPly`는 **실제로 둔 수만** 집계한 값이고, 종반 solver가 처리한 수순은 포함하지 않습니다.
- `their-noise-scale=4`는 upstream 엔진의 난수 잡음을 유지합니다.
- 더 재현성 높은 비교가 필요하면 `their-noise-scale=0`으로 두고 진단용으로 볼 수 있습니다. 다만 이 경우 upstream 웹 배포 엔진과는 완전히 동일하지 않습니다.

## 주의 사항

- upstream trineutron 엔진은 evaluation에 가우시안 잡음을 넣기 때문에, **판 수가 적으면 결과가 출렁일 수 있습니다.**
- 종반 solver adjudication은 **승패/기보 마진 비교를 더 안정적으로** 만들어 주지만, 중반부 착수 선택의 변동성 자체를 없애지는 않습니다.
- `their-max-depth` 기본값은 실용적인 오프라인 벤치마크를 위해 `18`로 제한했습니다. 종반은 solver adjudication으로 잘라내므로, 굳이 trineutron의 late exact spill까지 모두 재현할 필요가 없습니다.

## 출력 JSON 구조

JSON에는 다음 정보가 들어갑니다.

- benchmark options
- opening suite 정보
- variant별 집계(`wins/losses/draws`, `scoreRate`, `averageDiscDiff`, `averagePlayedPly`)
- exact adjudication 횟수와 해당 노드/시간 집계
- 색상별 집계
- 각 게임의 move log, 총 시간, 총 노드 수, 종료 방식(`played-out` 또는 `exact-adjudication`)


## generated module 직접 벤치하기

이제 `benchmark-vs-trineutron.mjs` 는 `--variants custom` 과 함께 `--generated-module` 또는 개별 JSON profile 입력을 받아,
앱의 `learned-eval-profile.generated.js` 를 임시 교체하지 않고도 candidate generated module을 바로 대국 벤치에 넣을 수 있습니다.

```bash
node tools/engine-match/benchmark-vs-trineutron.mjs \
  --variants custom \
  --generated-module tools/evaluator-training/out/learned-eval-profile.generated.js \
  --variant-label diagonal-latea-endgame-top24 \
  --games 2 --opening-plies 20 --seed 11 \
  --our-time-ms 100 --their-time-ms 100 --their-noise-scale 0
```
