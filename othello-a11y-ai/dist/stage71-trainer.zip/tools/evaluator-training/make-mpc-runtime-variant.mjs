#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

import {
  buildProfileStageMetadata,
  displayTrainingOutputPath,
  displayTrainingToolPath,
  loadJsonFileIfPresent,
  parseArgs,
  resolveCliPath,
  sanitizeMpcProfileForModule,
  toPortablePath,
} from './lib.mjs';

function printUsage() {
  const toolPath = displayTrainingToolPath('make-mpc-runtime-variant.mjs');
  const inputPath = displayTrainingOutputPath('trained-mpc-profile.json');
  const outputPath = displayTrainingOutputPath('candidate-mpc-profile.json');
  console.log(`Usage:
  node ${toolPath} \
    --input-profile ${inputPath} \
    --output-json ${outputPath} \
    [--name candidate-mpc-profile-name] \
    [--description "설명"] \
    [--enable-high-cut on|off] \
    [--enable-low-cut on|off] \
    [--max-window 1] \
    [--max-checks-per-node 1] \
    [--min-depth 2] \
    [--min-depth-gap 2] \
    [--max-depth-distance 1] \
    [--min-ply 1] \
    [--allow-root on|off] \
    [--high-scale 1.0] \
    [--low-scale 1.0] \
    [--depth-distance-scale 1.25]

설명:
- 기존 MPC profile JSON의 calibration 계수는 그대로 두고, 런타임 pruning 동작만 조정한 파생 profile을 생성합니다.
- 현재 구현은 zero-window MPC probe를 사용하며, high/low cut 활성화, 허용 window, 노드당 시도 횟수, 깊이 조건, interval scale을 바꿔 비교 벤치마크할 때 유용합니다.
- 이 도구는 새 shallow/deep 회귀를 재학습하지 않습니다. 여러 shallow depth / 겹치는 empties 구간을 새로 학습하려면 calibrate-mpc-profile.mjs에서 calibration-buckets를 확장해 다시 학습하십시오.
`);
}

function cloneJson(value) {
  return JSON.parse(JSON.stringify(value));
}

function parseBooleanFlag(value, flagName) {
  if (typeof value === 'boolean') {
    return value;
  }
  const normalized = String(value ?? '').trim().toLowerCase();
  if (normalized === 'on' || normalized === 'true' || normalized === '1' || normalized === 'yes') {
    return true;
  }
  if (normalized === 'off' || normalized === 'false' || normalized === '0' || normalized === 'no') {
    return false;
  }
  throw new Error(`${flagName} 값은 on/off, true/false, 1/0 중 하나여야 합니다: ${value}`);
}

function parseFiniteInteger(value, flagName, { min = -Infinity, max = Infinity } = {}) {
  const number = Number(value);
  if (!Number.isFinite(number) || !Number.isInteger(Math.round(number))) {
    throw new Error(`${flagName} 값이 정수가 아닙니다: ${value}`);
  }
  const rounded = Math.round(number);
  if (rounded < min || rounded > max) {
    throw new Error(`${flagName} 값은 ${min} 이상 ${max} 이하여야 합니다: ${rounded}`);
  }
  return rounded;
}

function parseFiniteNumber(value, flagName, { min = -Infinity, max = Infinity } = {}) {
  const number = Number(value);
  if (!Number.isFinite(number)) {
    throw new Error(`${flagName} 값이 숫자가 아닙니다: ${value}`);
  }
  if (number < min || number > max) {
    throw new Error(`${flagName} 값은 ${min} 이상 ${max} 이하여야 합니다: ${number}`);
  }
  return number;
}

const args = parseArgs(process.argv.slice(2));
if (args.help || args.h || !args['input-profile'] || !args['output-json']) {
  printUsage();
  process.exit(args.help || args.h ? 0 : 1);
}

const inputProfilePath = resolveCliPath(args['input-profile']);
const outputJsonPath = resolveCliPath(args['output-json']);
const baseProfile = loadJsonFileIfPresent(inputProfilePath);
if (!baseProfile) {
  throw new Error(`input profile을 읽을 수 없습니다: ${inputProfilePath}`);
}

const normalizedBaseProfile = sanitizeMpcProfileForModule(baseProfile);
const nextProfile = cloneJson(normalizedBaseProfile);
const baseRuntime = nextProfile.runtime && typeof nextProfile.runtime === 'object'
  ? { ...nextProfile.runtime }
  : {};
const nextRuntime = { ...baseRuntime };
const changedFields = [];

function assignRuntimeField(key, value) {
  if (baseRuntime[key] === value) {
    return;
  }
  nextRuntime[key] = value;
  changedFields.push({ key, before: baseRuntime[key], after: value });
}

if (Object.hasOwn(args, 'enable-high-cut')) {
  assignRuntimeField('enableHighCut', parseBooleanFlag(args['enable-high-cut'], '--enable-high-cut'));
}
if (Object.hasOwn(args, 'enable-low-cut')) {
  assignRuntimeField('enableLowCut', parseBooleanFlag(args['enable-low-cut'], '--enable-low-cut'));
}
if (Object.hasOwn(args, 'max-window')) {
  assignRuntimeField('maxWindow', parseFiniteInteger(args['max-window'], '--max-window', { min: 1, max: 64 }));
}
if (Object.hasOwn(args, 'max-checks-per-node')) {
  assignRuntimeField('maxChecksPerNode', parseFiniteInteger(args['max-checks-per-node'], '--max-checks-per-node', { min: 1, max: 8 }));
}
if (Object.hasOwn(args, 'min-depth')) {
  assignRuntimeField('minDepth', parseFiniteInteger(args['min-depth'], '--min-depth', { min: 1, max: 64 }));
}
if (Object.hasOwn(args, 'min-depth-gap')) {
  assignRuntimeField('minDepthGap', parseFiniteInteger(args['min-depth-gap'], '--min-depth-gap', { min: 1, max: 32 }));
}
if (Object.hasOwn(args, 'max-depth-distance')) {
  assignRuntimeField('maxDepthDistance', parseFiniteInteger(args['max-depth-distance'], '--max-depth-distance', { min: 0, max: 32 }));
}
if (Object.hasOwn(args, 'min-ply')) {
  assignRuntimeField('minPly', parseFiniteInteger(args['min-ply'], '--min-ply', { min: 0, max: 64 }));
}
if (Object.hasOwn(args, 'allow-root')) {
  assignRuntimeField('minPly', parseBooleanFlag(args['allow-root'], '--allow-root') ? 0 : (nextRuntime.minPly ?? 1));
}
if (Object.hasOwn(args, 'high-scale')) {
  assignRuntimeField('highScale', parseFiniteNumber(args['high-scale'], '--high-scale', { min: 0, max: 10 }));
}
if (Object.hasOwn(args, 'low-scale')) {
  assignRuntimeField('lowScale', parseFiniteNumber(args['low-scale'], '--low-scale', { min: 0, max: 10 }));
}
if (Object.hasOwn(args, 'depth-distance-scale')) {
  assignRuntimeField('depthDistanceScale', parseFiniteNumber(args['depth-distance-scale'], '--depth-distance-scale', { min: 1, max: 10 }));
}

if (changedFields.length === 0) {
  throw new Error('변경된 runtime 파라미터가 없습니다. 최소 한 개 이상의 --enable-*/--max-*/--scale 옵션을 지정하십시오.');
}

nextProfile.runtime = nextRuntime;
nextProfile.name = typeof args.name === 'string' && args.name.trim() !== ''
  ? args.name.trim()
  : `${normalizedBaseProfile.name ?? 'mpc-profile'}__runtime-variant`;
nextProfile.description = typeof args.description === 'string'
  ? args.description
  : `${normalizedBaseProfile.description ?? 'mpc profile'} (runtime-derived variant)`;

nextProfile.stage = buildProfileStageMetadata({
  kind: 'mpc-profile',
  status: 'runtime-variant',
  derivedFromProfileName: normalizedBaseProfile.name ?? null,
  derivedFromProfilePath: toPortablePath(path.relative(process.cwd(), inputProfilePath) || path.basename(inputProfilePath)),
});

const baseSource = baseProfile && typeof baseProfile.source === 'object' && baseProfile.source
  ? cloneJson(baseProfile.source)
  : {};
nextProfile.source = {
  ...baseSource,
  derivedFromProfileName: normalizedBaseProfile.name ?? null,
  derivedFromProfilePath: toPortablePath(path.relative(process.cwd(), inputProfilePath) || path.basename(inputProfilePath)),
  derivedAt: new Date().toISOString(),
  runtimeVariant: {
    changedFields,
  },
};

const baseDiagnostics = baseProfile && typeof baseProfile.diagnostics === 'object' && baseProfile.diagnostics
  ? cloneJson(baseProfile.diagnostics)
  : {};
nextProfile.diagnostics = {
  ...baseDiagnostics,
  runtimeVariant: {
    baseProfileName: normalizedBaseProfile.name ?? null,
    changedFieldCount: changedFields.length,
    changedFields,
  },
};

await fs.promises.mkdir(path.dirname(outputJsonPath), { recursive: true });
await fs.promises.writeFile(outputJsonPath, `${JSON.stringify(nextProfile, null, 2)}\n`, 'utf8');

console.log(`Base profile : ${normalizedBaseProfile.name ?? path.basename(inputProfilePath)}`);
console.log(`Output       : ${outputJsonPath}`);
console.log(`Runtime diff : ${changedFields.length} field(s)`);
for (const change of changedFields) {
  console.log(`  ${change.key}: ${String(change.before)} -> ${String(change.after)}`);
}
