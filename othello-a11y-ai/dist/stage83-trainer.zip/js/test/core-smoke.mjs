import assert from 'node:assert/strict';
import {
  GameState,
  createStateFromBitboards,
  createStateFromMoveSequence,
  createStateHistoryFromMoveSequence,
} from '../core/game-state.js';
import { bitFromIndex, FULL_BOARD, popcount } from '../core/bitboard.js';
import { SearchEngine } from '../ai/search-engine.js';
import { legalMovesBitboard } from '../core/rules.js';
import { Evaluator, MoveOrderingEvaluator, describeStableDiscBounds } from '../ai/evaluator.js';
import { lookupOpeningBook, getOpeningBookSummary } from '../ai/opening-book.js';
import { resolveEngineOptions } from '../ai/presets.js';
import { DEFAULT_EVALUATION_PROFILE } from '../ai/evaluation-profiles.js';
import { formatSearchSummary } from '../ui/formatters.js';

function coordinatesOfLegalMoves(state) {
  return state.getLegalMoves().map((move) => move.coord).sort();
}

function playDeterministicPly(state, plies) {
  let current = state;
  for (let ply = 0; ply < plies; ply += 1) {
    const legalMoves = current.getLegalMoves().sort((left, right) => left.coord.localeCompare(right.coord));
    if (legalMoves.length === 0) {
      current = current.passTurn();
      continue;
    }
    current = current.applyMove(legalMoves[0].index).state;
  }
  return current;
}

function playDeterministicallyUntilEmptyCount(state, targetEmptyCount) {
  let current = state;
  let guard = 0;
  while (!current.isTerminal() && current.getEmptyCount() > targetEmptyCount) {
    const legalMoves = current.getLegalMoves().sort((left, right) => left.coord.localeCompare(right.coord));
    current = legalMoves.length === 0
      ? current.passTurn()
      : current.applyMove(legalMoves[0].index).state;

    guard += 1;
    assert.ok(guard < 200, 'Deterministic playout should not loop forever.');
  }
  return current;
}

function createSeededRandom(seed) {
  let value = seed >>> 0;
  return () => {
    value = (Math.imul(value, 1664525) + 1013904223) >>> 0;
    return value / 0x100000000;
  };
}

function playSeededRandomUntilEmptyCount(targetEmptyCount, seed) {
  const random = createSeededRandom(seed);
  let current = GameState.initial();
  let guard = 0;

  while (!current.isTerminal() && current.getEmptyCount() > targetEmptyCount) {
    const legalMoves = current.getLegalMoves().sort((left, right) => left.coord.localeCompare(right.coord));
    current = legalMoves.length === 0
      ? current.passTurn()
      : current.applyMove(legalMoves[Math.floor(random() * legalMoves.length)].index).state;

    guard += 1;
    assert.ok(guard < 200, 'Seeded playout should not loop forever.');
  }

  return current;
}

function withMockedRandom(value, callback) {
  const originalRandom = Math.random;
  Math.random = () => value;
  try {
    return callback();
  } finally {
    Math.random = originalRandom;
  }
}

function referencePopcount(bitboard) {
  let count = 0;
  let cursor = bitboard;
  while (cursor !== 0n) {
    cursor &= cursor - 1n;
    count += 1;
  }
  return count;
}

function findSearchRandomnessRegressionState() {
  const probeEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 600,
    exactEndgameEmpties: 8,
    aspirationWindow: 40,
    randomness: 0,
  });

  for (let plies = 13; plies <= 32; plies += 1) {
    const state = playDeterministicPly(GameState.initial(), plies);
    const result = probeEngine.findBestMove(state, {
      presetKey: 'custom',
      maxDepth: 4,
      timeLimitMs: 600,
      exactEndgameEmpties: 8,
      aspirationWindow: 40,
      randomness: 0,
      styleKey: 'balanced',
    });

    if (result.source !== 'search' || result.analyzedMoves.length < 2) {
      continue;
    }

    if ((result.analyzedMoves[0].score - result.analyzedMoves[1].score) <= 60) {
      return state;
    }
  }

  return null;
}


function assertZeroSumEvaluation(evaluator, state, message) {
  const blackScore = evaluator.evaluate(state, 'black');
  const whiteScore = evaluator.evaluate(state, 'white');
  assert.ok(
    Object.is(blackScore, -whiteScore) || (blackScore + whiteScore) === 0,
    `${message}: black ${blackScore}, white ${whiteScore}`,
  );
}

function bruteForceExactScore(state) {
  if (state.isTerminal()) {
    return state.getDiscDifferential(state.currentPlayer) * 10000;
  }

  const legalMoves = state.getLegalMoves();
  if (legalMoves.length === 0) {
    return -bruteForceExactScore(state.passTurn());
  }

  let bestScore = -Infinity;
  for (const move of legalMoves) {
    const outcome = state.applyMove(move.index);
    assert.ok(outcome, 'Brute-force solver should only examine legal moves.');
    bestScore = Math.max(bestScore, -bruteForceExactScore(outcome.state));
  }
  return bestScore;
}

function classifyOutcomeFromScore(score) {
  if (score > 0) {
    return 'win';
  }
  if (score < 0) {
    return 'loss';
  }
  return 'draw';
}

function findSeededStateWithMinimumLegalMoves(targetEmptyCount, minimumLegalMoves = 2, maxSeed = 120) {
  for (let seed = 1; seed <= maxSeed; seed += 1) {
    const state = playSeededRandomUntilEmptyCount(targetEmptyCount, seed);
    if (state.getEmptyCount() !== targetEmptyCount) {
      continue;
    }

    if (state.getLegalMoves().length >= minimumLegalMoves) {
      return state;
    }
  }

  return null;
}

function captureSearchTimeoutErrorInstance(engine) {
  const originalDeadline = engine.deadlineMs;
  engine.deadlineMs = Number.NEGATIVE_INFINITY;
  try {
    engine.checkDeadline();
    assert.fail('Forcing the deadline into the past should surface a SearchTimeoutError instance.');
  } catch (error) {
    assert.equal(error.name, 'SearchTimeoutError', 'The timeout regression helper must capture the engine-specific timeout type.');
    return error;
  } finally {
    engine.deadlineMs = originalDeadline;
  }
}

function findExactRootTimeoutRegressionState() {
  const probeEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 16,
    aspirationWindow: 0,
    randomness: 0,
  });

  for (let empties = 16; empties >= 10; empties -= 1) {
    for (let seed = 1; seed <= 40; seed += 1) {
      const state = playSeededRandomUntilEmptyCount(empties, seed);
      if (state.getEmptyCount() !== empties) {
        continue;
      }

      const legalMoves = state.getLegalMoves();
      if (legalMoves.length < 2) {
        continue;
      }

      const orderedMoves = probeEngine.orderMoves(state, legalMoves, 0, probeEngine.options.maxDepth, null, null);
      if (orderedMoves.length < 2) {
        continue;
      }

      const fallback = probeEngine.buildRootFallback(state, legalMoves, null);
      if (fallback.bestMoveIndex === orderedMoves[0].index) {
        continue;
      }

      return {
        state,
        firstOrderedMove: orderedMoves[0],
        fallback,
      };
    }
  }

  return null;
}

function runCoreRuleTests() {
  const representativeBitboards = [
    0n,
    FULL_BOARD,
    0xaaaaaaaa55555555n,
    bitFromIndex(0) | bitFromIndex(31) | bitFromIndex(32) | bitFromIndex(63),
    bitFromIndex(7) | bitFromIndex(8) | bitFromIndex(9) | bitFromIndex(54),
    legalMovesBitboard(GameState.initial().black, GameState.initial().white),
  ];
  for (let index = 0; index < 64; index += 1) {
    representativeBitboards.push(bitFromIndex(index));
  }
  for (const bitboard of representativeBitboards) {
    assert.equal(
      popcount(bitboard),
      referencePopcount(bitboard),
      `popcount should match the reference implementation for ${bitboard.toString(16)}h.`,
    );
  }

  const initial = GameState.initial();
  const initialMoves = coordinatesOfLegalMoves(initial);
  assert.deepEqual(initialMoves, ['C4', 'D3', 'E6', 'F5']);

  const moveResult = initial.applyMove(initial.getLegalMoves().find((move) => move.coord === 'D3').index);
  assert.ok(moveResult, 'D3 should be legal for black from the initial position.');
  assert.equal(moveResult.move.coord, 'D3');
  assert.deepEqual(moveResult.move.flippedCoords, ['D4']);
  assert.equal(moveResult.state.currentPlayer, 'white');

  const fastState = initial.applyMoveFast(initial.getLegalMoves().find((move) => move.coord === 'D3').index);
  assert.ok(fastState, 'Fast move application should accept the same legal move.');
  assert.equal(fastState.black, moveResult.state.black, 'Fast move application should match the regular board update.');
  assert.equal(fastState.white, moveResult.state.white, 'Fast move application should match the regular board update.');
  assert.equal(fastState.currentPlayer, moveResult.state.currentPlayer, 'Fast move application should preserve the side to move.');

  assert.deepEqual(
    initial.getSearchMoves().map((move) => move.index),
    initial.getLegalMoves().map((move) => move.index),
    'Search move generation should list the same legal moves as the full-detail UI generator.',
  );

  const imported = createStateFromMoveSequence('c4c3');
  assert.equal(imported.currentPlayer, 'black', 'Compact move-sequence input should be accepted.');
  assert.deepEqual(imported.getDiscCounts(), { black: 3, white: 3 });

  const cloneHash = imported.clone().hashKey();
  assert.equal(typeof cloneHash, 'bigint', 'Hash keys should use a packed BigInt representation.');
  assert.equal(cloneHash, imported.hashKey(), 'Cloning should preserve the same hash key.');

  const sideToMoveChanged = createStateFromBitboards({
    black: imported.black,
    white: imported.white,
    currentPlayer: 'white',
  });
  assert.notEqual(
    imported.hashKey(),
    sideToMoveChanged.hashKey(),
    'Hash keys should distinguish the side to move for transposition lookups.',
  );

  const history = createStateHistoryFromMoveSequence('C4 C3');
  assert.equal(history.length, 3, 'Position import should preserve the full state history from the opening state.');
  assert.equal(history.at(-1).moveHistory.length, 2);

  assert.throws(
    () => createStateHistoryFromMoveSequence('pass'),
    /Illegal pass/i,
    'Position import should reject pass tokens while legal moves still exist.',
  );

  assert.throws(
    () => createStateFromBitboards({ black: 1n, white: 1n }),
    /overlap/i,
    'Bitboard import should reject overlapping occupancy.',
  );
}

function runEvaluatorTests() {
  const initial = GameState.initial();
  const evaluator = new Evaluator();
  const initialScore = evaluator.evaluate(initial);
  assert.ok(Number.isFinite(initialScore));

  const progressed = playDeterministicPly(initial, 12);
  const progressedScore = evaluator.evaluate(progressed);
  assert.ok(Number.isFinite(progressedScore));
  assert.notEqual(progressedScore, initialScore, 'A changed position should usually change the evaluation.');

  const lateGame = playDeterministicPly(initial, 49);
  assert.equal(lateGame.getEmptyCount(), 14, 'The parity regression test should reach the late game.');
  assertZeroSumEvaluation(
    evaluator,
    lateGame,
    'Evaluations from opposite perspectives should stay zero-sum in the late game',
  );

  for (const seed of [11, 23, 37, 59, 71, 89]) {
    const randomLate = playSeededRandomUntilEmptyCount(10 + (seed % 6), seed);
    assertZeroSumEvaluation(
      evaluator,
      randomLate,
      `Evaluations from opposite perspectives should stay zero-sum on seeded regression ${seed}`,
    );
  }

  const orderingEvaluator = new MoveOrderingEvaluator();
  assertZeroSumEvaluation(
    orderingEvaluator,
    lateGame,
    'Move-ordering evaluations should stay zero-sum in the late game',
  );

  const cornerSafe = createStateFromMoveSequence('D3 C3 B3 B2 C4 A3 A1');
  const cornerRisky = createStateFromMoveSequence('D3 C3 B3 B2 B1');
  const safeFeatures = evaluator.explainFeatures(cornerSafe, 'black');
  const riskyFeatures = evaluator.explainFeatures(cornerRisky, 'black');
  assert.ok(Number.isFinite(safeFeatures.edgePattern), 'Edge pattern feature should be computed for analysis output.');
  assert.ok(Number.isFinite(safeFeatures.cornerPattern), 'Corner pattern feature should be computed for analysis output.');
  assert.ok(Number.isFinite(safeFeatures.cornerOrthAdjacency), 'Orthogonal corner-adjacency feature should be exposed for learning.');
  assert.ok(Number.isFinite(safeFeatures.cornerDiagonalAdjacency), 'Diagonal corner-adjacency feature should be exposed for learning.');
  assert.equal(typeof safeFeatures.phaseBucketKey, 'string', 'Feature breakdown should expose the selected phase bucket.');
  assert.equal(typeof safeFeatures.bucketWeights.mobility, 'number', 'Feature breakdown should expose the applied bucket weights.');
  assert.ok(
    safeFeatures.cornerPattern > riskyFeatures.cornerPattern,
    'Owning a corner should improve the corner-pattern score compared with lingering near an empty corner.',
  );

  const customProfile = {
    ...DEFAULT_EVALUATION_PROFILE,
    name: 'smoke-custom-profile',
    phaseBuckets: DEFAULT_EVALUATION_PROFILE.phaseBuckets.map((bucket) => ({
      ...bucket,
      weights: {
        ...bucket.weights,
        mobility: bucket.weights.mobility + 1,
      },
    })),
  };
  const customProfileEvaluator = new Evaluator({ evaluationProfile: customProfile });
  const customScore = customProfileEvaluator.evaluate(progressed, 'black');
  assert.ok(Number.isFinite(customScore), 'Custom evaluation profiles should compile and evaluate normally.');
  assert.equal(
    customProfileEvaluator.explainFeatures(progressed, 'black').evaluationProfileName,
    'smoke-custom-profile',
    'Custom evaluation profile names should appear in feature diagnostics.',
  );

  const cornerAccessState = createStateFromMoveSequence('D3 C3 B3 B2 C4 A3');
  const cornerAccessBlackFeatures = evaluator.explainFeatures(cornerAccessState, 'black');
  const cornerAccessWhiteFeatures = evaluator.explainFeatures(cornerAccessState, 'white');
  assert.equal(
    cornerAccessBlackFeatures.cornerAccess,
    100,
    'The evaluator should report an uncontested immediate corner as the maximum corner-access advantage.',
  );
  assert.deepEqual(
    cornerAccessBlackFeatures.cornerMoves,
    ['A1'],
    'The feature breakdown should expose the exact corner move available to the side with access.',
  );
  assert.deepEqual(
    cornerAccessBlackFeatures.opponentCornerMoves,
    [],
    'The feature breakdown should show when the opponent has no immediate corner reply.',
  );
  assert.equal(
    cornerAccessWhiteFeatures.cornerAccess,
    -100,
    'Corner-access reporting should remain zero-sum from the opposite perspective.',
  );

  const mixedFullEdge = createStateFromBitboards({
    black: 153n,
    white: 102n,
    currentPlayer: 'black',
  });
  const mixedEdgeBlackFeatures = evaluator.explainFeatures(mixedFullEdge, 'black');
  const mixedEdgeWhiteFeatures = evaluator.explainFeatures(mixedFullEdge, 'white');
  assert.equal(
    mixedEdgeBlackFeatures.stability,
    0,
    'A fully occupied edge should count all edge discs as stable even when the edge colors are mixed.',
  );
  assert.equal(
    mixedEdgeWhiteFeatures.stability,
    0,
    'Mixed full-edge stability should remain zero-sum from the opposite perspective as well.',
  );

  const interiorStabilityBase = createStateFromBitboards({
    black: 104991460194059647n,
    white: 18341066517284440192n,
    currentPlayer: 'black',
  });
  const interiorStabilityBoosted = createStateFromBitboards({
    black: 104991460194059647n | bitFromIndex(9),
    white: 18341066517284440192n,
    currentPlayer: 'black',
  });
  const interiorBaseFeatures = evaluator.explainFeatures(interiorStabilityBase, 'black');
  const interiorBoostedFeatures = evaluator.explainFeatures(interiorStabilityBoosted, 'black');
  assert.ok(
    interiorBoostedFeatures.stableDiscs > interiorBaseFeatures.stableDiscs,
    'Late-game stability refinement should propagate beyond edge anchors when an interior disc is shielded by stable chains.',
  );
  assert.ok(
    interiorBoostedFeatures.stability > interiorBaseFeatures.stability,
    'Additional interior stable discs should improve the reported stability score.',
  );

  const splitParityWhite = bitFromIndex(1) | bitFromIndex(61);
  const splitParityState = createStateFromBitboards({
    black: FULL_BOARD & ~(bitFromIndex(0) | bitFromIndex(63) | splitParityWhite),
    white: splitParityWhite,
    currentPlayer: 'black',
  });
  const splitParityBlackFeatures = evaluator.explainFeatures(splitParityState, 'black');
  const splitParityWhiteFeatures = evaluator.explainFeatures(splitParityState, 'white');
  assert.equal(
    splitParityBlackFeatures.parityGlobal,
    -100,
    'Global parity should still see an even number of remaining empties as unfavorable for the side to move.',
  );
  assert.equal(
    splitParityBlackFeatures.parityRegionCount,
    2,
    'Region-aware parity should recognize the two isolated singleton empty regions.',
  );
  assert.equal(
    splitParityBlackFeatures.parityOddRegions,
    2,
    'Both isolated singleton regions should count as odd empty regions.',
  );
  assert.ok(
    splitParityBlackFeatures.parity > splitParityBlackFeatures.parityGlobal,
    'Region-aware parity should soften the flat global-even penalty when the odd regions are split between the players.',
  );
  assert.equal(
    splitParityWhiteFeatures.parity,
    -splitParityBlackFeatures.parity,
    'Region-aware parity should remain zero-sum across opposite evaluation perspectives.',
  );
}


function runOpeningBookTests() {
  const summary = getOpeningBookSummary();
  assert.equal(summary.baseSeedLineCount, 99, 'Base opening book should preserve the original Robert Gatliff seed catalog size.');
  assert.equal(summary.supplementalSeedLineCount, 12, 'Supplemental named continuations should be tracked separately from the base catalog.');
  assert.equal(summary.seedLineCount, 111, 'Combined opening book should expose the expanded seed line count.');
  assert.ok(summary.positionCount > 600, 'Expanded opening book should cover several hundred reachable positions.');
  assert.ok(summary.maxDepthPly >= 20, 'Expanded opening book should now reach deep named continuations.');

  const initial = GameState.initial();
  const initialHit = lookupOpeningBook(initial);
  assert.ok(initialHit, 'Initial position should be present in the opening book.');
  assert.equal(initialHit.candidateCount, 4, 'Initial position should expose all four standard first moves.');

  const diagonalState = initial.applyMove(initial.getLegalMoves().find((move) => move.coord === 'D3').index).state;
  const diagonalHit = lookupOpeningBook(diagonalState);
  assert.ok(diagonalHit, 'Symmetric early openings should also be found in the opening book.');

  const bondPrefixState = createStateFromMoveSequence('F5 D6 C3 D3 C4 F4 F6 G5 E6 D7 E3 C5 F3 E7');
  const bondHit = lookupOpeningBook(bondPrefixState);
  assert.ok(bondHit, 'Supplemental no-kung continuations should be reachable from the opening book.');
  assert.equal(bondHit.candidates[0].coord, 'B6', 'Bond prefix should point to the named continuation move.');
  assert.equal(bondHit.candidates[0].topNames[0]?.name, 'Bond', 'Bond continuation should preserve its named label at the candidate level.');

  const toriPrefixState = createStateFromMoveSequence('F5 D6 C3 D3 C4 F4 C5 B3 C2 E3 D2 C6 B4');
  const toriHit = lookupOpeningBook(toriPrefixState);
  assert.ok(toriHit, 'Supplemental tiger-heavy continuations should be reachable from the opening book.');
  assert.deepEqual(
    toriHit.candidates.map((candidate) => candidate.coord).slice(0, 2),
    ['A3', 'A4'],
    'Tori prefix should expose the hook and straight continuations side by side.',
  );
  assert.deepEqual(
    toriHit.candidates.map((candidate) => candidate.topNames[0]?.name).slice(0, 2),
    ['Tori Hook (酉フック)', 'Tori Straight (酉ストレート)'],
    'Tori continuations should preserve their distinct named labels.',
  );

  const supermanPrefixState = createStateFromMoveSequence('F5 F6 E6 F4 E3 C5 C4 D6 C6 B3 D7 D3 F3');
  const supermanHit = lookupOpeningBook(supermanPrefixState);
  assert.ok(supermanHit, 'Supplemental cow-family continuations should be reachable from the opening book.');
  assert.equal(supermanHit.candidates[0].coord, 'D2', 'Superman prefix should point to the named continuation move.');
  assert.equal(supermanHit.candidates[0].topNames[0]?.name, 'Superman', 'Superman continuation should preserve its named label at the candidate level.');
}

function runPresetResolutionTests() {
  const beginner = resolveEngineOptions('beginner', {}, 'balanced');
  const easy = resolveEngineOptions('easy', {}, 'balanced');
  const balanced = resolveEngineOptions('hard', {}, 'balanced');
  const aggressive = resolveEngineOptions('hard', {}, 'aggressive');
  const fortress = resolveEngineOptions('hard', {}, 'fortress');
  const expert = resolveEngineOptions('expert', {}, 'balanced');
  const impossible = resolveEngineOptions('impossible', {}, 'balanced');
  const custom = resolveEngineOptions('custom', {
    maxDepth: 7,
    randomness: 5,
    mobilityScale: 1.4,
    riskPenaltyScale: 1.1,
  }, 'aggressive');
  const customWithWld = resolveEngineOptions('custom', {
    wldPreExactEmpties: 2,
  }, 'balanced');

  assert.equal(easy.presetKey, 'easy');
  assert.equal(easy.maxDepth, 3, 'Easy should sit between beginner and normal at depth 3.');
  assert.equal(easy.exactEndgameEmpties, 6, 'Easy should begin exact endgame search from 6 empties.');
  assert.ok(beginner.timeLimitMs < easy.timeLimitMs, 'Easy should think longer than beginner.');
  assert.ok(easy.randomness < beginner.randomness, 'Easy should be less random than beginner.');
  assert.equal(impossible.presetKey, 'impossible');
  assert.equal(impossible.maxDepth, 10, 'Impossible should target depth 10.');
  assert.equal(impossible.exactEndgameEmpties, 16, 'Impossible should extend exact search to 16 empties.');
  assert.ok(impossible.timeLimitMs > 10000, 'Impossible should reserve a heavy think time budget.');
  assert.ok(impossible.timeLimitMs > expert.timeLimitMs, 'Impossible should think longer than expert.');
  assert.ok(impossible.maxTableEntries > expert.maxTableEntries, 'Impossible should allocate a larger transposition table budget.');
  assert.equal(balanced.styleKey, 'balanced');
  assert.equal(aggressive.styleKey, 'aggressive');
  assert.ok(aggressive.mobilityScale > balanced.mobilityScale, 'Aggressive style should raise mobility emphasis.');
  assert.ok(fortress.stabilityScale > balanced.stabilityScale, 'Fortress style should raise stability emphasis.');
  assert.ok(fortress.edgePatternScale > balanced.edgePatternScale, 'Fortress style should value edge patterns more strongly.');
  assert.ok(fortress.cornerPatternScale > balanced.cornerPatternScale, 'Fortress style should value corner patterns more strongly.');
  assert.ok(fortress.randomness <= aggressive.randomness, 'Fortress style should stay at least as deterministic as aggressive.');
  assert.equal(custom.styleKey, null);
  assert.equal(custom.styleApplied, false);
  assert.equal(custom.mobilityScale, 1.4, 'Custom inputs should bypass style-based scaling.');
  assert.equal(custom.randomness, 5, 'Custom randomness should bypass style-based randomness bonuses.');
  assert.equal(custom.wldPreExactEmpties, 0, 'Custom preset should keep WLD pre-exact mode disabled unless the user explicitly enables it.');
  assert.equal(customWithWld.wldPreExactEmpties, 2, 'Custom preset should accept the explicit +2 WLD pre-exact option.');

  const directOverrideEngine = new SearchEngine({
    maxDepth: 5,
    timeLimitMs: 1300,
    exactEndgameEmpties: 11,
    aspirationWindow: 15,
    randomness: 0,
  });
  assert.equal(directOverrideEngine.options.presetKey, 'normal', 'Bare constructor overrides should still inherit the default normal preset label.');
  assert.equal(directOverrideEngine.options.maxDepth, 5, 'Bare constructor overrides should honor direct maxDepth input.');
  assert.equal(directOverrideEngine.options.timeLimitMs, 1300, 'Bare constructor overrides should honor direct timeLimitMs input.');
  assert.equal(directOverrideEngine.options.exactEndgameEmpties, 11, 'Bare constructor overrides should honor direct exact-endgame input.');
  assert.equal(directOverrideEngine.options.randomness, 0, 'Bare constructor overrides should honor direct randomness input.');

  const uiSemanticsEngine = new SearchEngine({
    presetKey: 'normal',
    styleKey: 'balanced',
    maxDepth: 1,
    timeLimitMs: 1300,
    exactEndgameEmpties: 11,
    randomness: 0,
  });
  assert.equal(uiSemanticsEngine.options.maxDepth, 4, 'Explicit preset-based search should keep ignoring non-custom depth overrides.');
  assert.equal(uiSemanticsEngine.options.timeLimitMs, 500, 'Explicit preset-based search should keep ignoring non-custom time overrides.');
  assert.equal(uiSemanticsEngine.options.exactEndgameEmpties, 8, 'Explicit preset-based search should keep ignoring non-custom exact-window overrides.');
  assert.equal(uiSemanticsEngine.options.randomness, 60, 'Explicit preset-based search should keep ignoring non-custom randomness overrides.');
}

function runSearchTests() {
  const engine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 600,
    exactEndgameEmpties: 8,
    aspirationWindow: 40,
    randomness: 0,
  });

  const initial = GameState.initial();
  const result = engine.findBestMove(initial);
  const legalMoveIndices = new Set(initial.getLegalMoveIndices());

  assert.ok(legalMoveIndices.has(result.bestMoveIndex), 'Engine must return a legal move.');
  assert.equal(result.source, 'opening-book', 'Initial position should be served directly from the opening book.');
  assert.equal(result.stats.bookHits, 1, 'Opening book lookup should be recorded in the stats.');
  assert.equal(result.stats.bookMoves, 1, 'Direct opening book moves should be recorded in the stats.');
  assert.ok(result.analyzedMoves.length > 0, 'Opening book result should expose candidate moves.');

  const midgame = playDeterministicPly(GameState.initial(), 17);
  const midgameResult = engine.findBestMove(midgame, { presetKey: 'custom', timeLimitMs: 500, maxDepth: 5, styleKey: 'fortress' });
  assert.ok(new Set(midgame.getLegalMoveIndices()).has(midgameResult.bestMoveIndex));
  assert.equal(midgameResult.source, 'search', 'Later positions should still fall back to full search.');
  assert.ok(midgameResult.stats.completedDepth >= 1, 'Full-search positions should complete at least one iteration.');
  assert.ok(midgameResult.analyzedMoves.length > 0);

  const randomnessRegressionState = findSearchRandomnessRegressionState();
  assert.ok(randomnessRegressionState, 'The regression test should find a search position with at least two near-best moves.');

  const randomizedEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 600,
    exactEndgameEmpties: 8,
    aspirationWindow: 40,
    randomness: 60,
  });
  const randomizedResult = withMockedRandom(0.999999, () => randomizedEngine.findBestMove(randomnessRegressionState, {
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 600,
    exactEndgameEmpties: 8,
    aspirationWindow: 40,
    randomness: 60,
    styleKey: 'balanced',
  }));
  assert.notEqual(
    randomizedResult.bestMoveIndex,
    randomizedResult.analyzedMoves[0].index,
    'Mocked randomness should force the engine to choose a non-top near-best move for this regression.',
  );
  const chosenAnalyzedMove = randomizedResult.analyzedMoves.find((move) => move.index === randomizedResult.bestMoveIndex);
  assert.ok(chosenAnalyzedMove, 'The randomized root move must still be present in the analyzed move list.');
  assert.equal(
    randomizedResult.principalVariation[0],
    randomizedResult.bestMoveIndex,
    'Randomized root selection must keep the principal variation aligned with the chosen move.',
  );
  assert.equal(
    randomizedResult.score,
    chosenAnalyzedMove.score,
    'Randomized root selection must keep the reported score aligned with the chosen move.',
  );

  const repeatedMidgameResult = engine.findBestMove(midgame, { presetKey: 'custom', timeLimitMs: 500, maxDepth: 5, styleKey: 'fortress' });
  assert.equal(
    repeatedMidgameResult.bestMoveIndex,
    midgameResult.bestMoveIndex,
    'Re-searching the same position with deterministic settings should keep the same best move.',
  );
  assert.ok(
    repeatedMidgameResult.stats.ttFirstSearches > 0,
    'A repeated search should reuse the stored transposition-table move before running full move ordering.',
  );

  const lmrProbe = playSeededRandomUntilEmptyCount(18, 7);
  assert.equal(lmrProbe.getEmptyCount(), 18, 'The LMR regression setup should land in a representative midgame.');
  const lmrEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 5,
    timeLimitMs: 1800,
    exactEndgameEmpties: 12,
    aspirationWindow: 40,
    randomness: 0,
  });
  const lmrResult = lmrEngine.findBestMove(lmrProbe, {
    presetKey: 'custom',
    maxDepth: 5,
    timeLimitMs: 1800,
    exactEndgameEmpties: 12,
    aspirationWindow: 40,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.ok(
    lmrResult.stats.lmrReductions > 0,
    'Conservative late-move reductions should activate on representative midgame searches.',
  );

  const orderingProbe = playSeededRandomUntilEmptyCount(12, 19);
  assert.equal(orderingProbe.getEmptyCount(), 12, 'Ordering-evaluator regression setup should reach twelve empties.');
  const orderingEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 5,
    timeLimitMs: 3000,
    exactEndgameEmpties: 16,
    aspirationWindow: 40,
    randomness: 0,
  });
  const orderingResult = orderingEngine.findBestMove(orderingProbe, {
    presetKey: 'custom',
    maxDepth: 5,
    timeLimitMs: 3000,
    exactEndgameEmpties: 16,
    aspirationWindow: 40,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.ok(
    orderingResult.stats.orderingEvalCalls > 0,
    'The lightweight move-ordering evaluator should activate in the intended late-search window.',
  );

  const childBucketProbe = playSeededRandomUntilEmptyCount(13, 21);
  assert.equal(childBucketProbe.getEmptyCount(), 13, 'Child-empty late-ordering regression setup should reach thirteen empties.');
  const childBucketMove = childBucketProbe.getSearchMoves()[0];
  const childBucketState = childBucketProbe.applyMoveFast(childBucketMove.index, childBucketMove.flips ?? null);
  const childBucketBoards = childBucketState.getPlayerBoards();
  const childBucketOpponentMoveCount = popcount(legalMovesBitboard(childBucketBoards.player, childBucketBoards.opponent));
  const parentPhaseOrderingScore = orderingEngine.scoreLightweightOrderingEvaluation(
    childBucketState,
    childBucketProbe.currentPlayer,
    childBucketProbe.getEmptyCount(),
    childBucketOpponentMoveCount,
  );
  const childPhaseOrderingScore = orderingEngine.scoreLightweightOrderingEvaluation(
    childBucketState,
    childBucketProbe.currentPlayer,
    childBucketState.getEmptyCount(),
    childBucketOpponentMoveCount,
  );
  assert.notEqual(
    childPhaseOrderingScore,
    parentPhaseOrderingScore,
    'Late move-ordering scoring should react to the post-move empty count so the trained 12-empty bucket activates immediately.',
  );

  const trainedThirteenBucket = orderingEngine.moveOrderingEvaluator.selectTrainedBucket(13);
  const activeThirteenBucket = orderingEngine.moveOrderingEvaluator.trainedWeightBuckets.find((bucket) => (
    13 >= bucket.minEmpties && 13 <= bucket.maxEmpties
  )) ?? null;
  assert.equal(
    trainedThirteenBucket?.key ?? null,
    activeThirteenBucket?.key ?? null,
    'The move-ordering evaluator should surface whichever trained child bucket actually covers thirteen empties in the active profile.',
  );
  if (trainedThirteenBucket) {
    for (const key of ['mobility', 'corners', 'cornerAdjacency', 'edgePattern', 'cornerPattern', 'discDifferential', 'parity']) {
      assert.ok(
        Number.isFinite(trainedThirteenBucket.weights?.[key]),
        `Active 13-empty trained bucket should expose a finite ${key} weight.`,
      );
    }
  }

  const exactLateOrderingProfile = orderingEngine.selectLateOrderingProfile(14);
  assert.ok(
    exactLateOrderingProfile.lightweightEvalScale >= 4,
    'Exact-window move ordering should strongly boost the trained lightweight evaluator signal.',
  );
  assert.equal(
    exactLateOrderingProfile.historyScale,
    0,
    'Exact-window move ordering should fully suppress generic history ordering noise after the Stage 10 retune.',
  );
  assert.equal(
    exactLateOrderingProfile.positionalScale,
    0,
    'Exact-window move ordering should fully suppress generic positional ordering noise after the Stage 10 retune.',
  );
  assert.equal(
    exactLateOrderingProfile.flipScale,
    0,
    'Exact-window move ordering should fully suppress generic flip-count ordering noise after the Stage 10 retune.',
  );
  assert.ok(
    exactLateOrderingProfile.riskScale < 0.3,
    'Exact-window move ordering should keep only a light residual positional-risk penalty.',
  );

  const tablePolicyEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 3,
    timeLimitMs: 200,
    maxTableEntries: 100,
    randomness: 0,
  });
  const tablePolicyState = playDeterministicPly(GameState.initial(), 6);
  const tablePolicyMoves = tablePolicyState.getLegalMoves();
  tablePolicyEngine.searchGeneration = 4;
  tablePolicyEngine.storeTransposition(tablePolicyState, {
    depth: 6,
    value: 40,
    flag: 'lower',
    bestMoveIndex: tablePolicyMoves[0].index,
  });
  tablePolicyEngine.searchGeneration = 5;
  tablePolicyEngine.storeTransposition(tablePolicyState, {
    depth: 4,
    value: 20,
    flag: 'exact',
    bestMoveIndex: tablePolicyMoves.at(-1).index,
  });
  const storedExactEntry = tablePolicyEngine.lookupTransposition(tablePolicyState);
  assert.equal(
    storedExactEntry.flag,
    'exact',
    'A shallower exact transposition entry should replace a moderately deeper bound entry for the same position.',
  );
  assert.equal(
    storedExactEntry.depth,
    4,
    'Exact transposition replacement should preserve the incoming exact entry depth.',
  );

  const agingEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 2,
    timeLimitMs: 100,
    randomness: 0,
  });
  agingEngine.options.maxTableEntries = 1000;
  agingEngine.transpositionTable.clear();
  for (let index = 0; index < 1000; index += 1) {
    agingEngine.transpositionTable.set(`stale-${index}`, {
      depth: 1,
      value: index,
      flag: index % 2 === 0 ? 'upper' : 'lower',
      bestMoveIndex: null,
      generation: 1,
    });
  }
  agingEngine.transpositionTable.set('recent-exact', {
    depth: 8,
    value: 500,
    flag: 'exact',
    bestMoveIndex: 19,
    generation: 5,
  });
  agingEngine.searchGeneration = 6;
  agingEngine.trimTranspositionTable();
  assert.ok(
    agingEngine.transpositionTable.has('recent-exact'),
    'Generation-aware trimming should keep recent deep exact entries.',
  );
  assert.ok(
    !agingEngine.transpositionTable.has('stale-0'),
    'Generation-aware trimming should evict stale shallow bound entries first.',
  );
  assert.ok(
    agingEngine.transpositionTable.size <= 881,
    'Table trimming should remove a significant stale batch once the entry budget is exceeded.',
  );

  const etcWindowState = GameState.initial();
  const etcWindowMoves = etcWindowState.getSearchMoves();
  assert.ok(etcWindowMoves.length >= 2, 'The ETC regression setup should expose at least two legal moves.');

  const etcFailHighEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 200,
    randomness: 0,
  });
  const etcFailHighChild = etcWindowState.applyMoveFast(etcWindowMoves[0].index, etcWindowMoves[0].flips ?? null);
  assert.ok(etcFailHighChild, 'The ETC fail-high regression child should be legal.');
  etcFailHighEngine.storeTransposition(etcFailHighChild, {
    depth: 2,
    value: -30000,
    flag: 'upper',
    bestMoveIndex: null,
  });
  const etcFailHigh = etcFailHighEngine.applyEnhancedTranspositionCutoff(
    etcWindowState,
    etcWindowMoves,
    3,
    -10000,
    10000,
    1,
    false,
  );
  assert.ok(etcFailHigh, 'The ETC helper should activate on root-child regression nodes.');
  assert.equal(etcFailHigh.cutoff, true, 'A strong child upper-bound should produce a conservative ETC fail-high cutoff.');
  assert.equal(etcFailHigh.score, 30000, 'The ETC fail-high cutoff should negate the child upper-bound into a parent lower-bound.');
  assert.equal(etcFailHigh.bestMoveIndex, etcWindowMoves[0].index, 'A fail-high ETC cutoff should remember the move that produced the proven lower-bound.');

  const etcFailLowEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 200,
    randomness: 0,
  });
  const failLowChildValues = [20000, 15000, 18000, 22000];
  for (let index = 0; index < etcWindowMoves.length; index += 1) {
    const move = etcWindowMoves[index];
    const child = etcWindowState.applyMoveFast(move.index, move.flips ?? null);
    assert.ok(child, 'The ETC fail-low regression children should all be legal.');
    etcFailLowEngine.storeTransposition(child, {
      depth: 2,
      value: failLowChildValues[index % failLowChildValues.length],
      flag: 'lower',
      bestMoveIndex: null,
    });
  }
  const etcFailLow = etcFailLowEngine.applyEnhancedTranspositionCutoff(
    etcWindowState,
    etcWindowMoves,
    3,
    -10000,
    5000,
    1,
    false,
  );
  assert.ok(etcFailLow, 'The ETC helper should return metadata for the fail-low regression setup as well.');
  assert.equal(etcFailLow.cutoff, true, 'A full set of child lower-bounds should allow conservative ETC fail-low pruning.');
  assert.equal(etcFailLow.score, -15000, 'The ETC fail-low cutoff should use the strongest parent upper-bound induced by the child lower-bounds.');
  assert.equal(etcFailLow.bestMoveIndex, null, 'A fail-low ETC cutoff should not invent a best move when only an upper-bound is known.');

  const etcActivityState = playDeterministicPly(GameState.initial(), 20);
  const etcActivityEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 5,
    timeLimitMs: 1000,
    exactEndgameEmpties: 8,
    aspirationWindow: 40,
    randomness: 0,
  });
  const etcActivityResult = etcActivityEngine.findBestMove(etcActivityState, {
    presetKey: 'custom',
    maxDepth: 5,
    timeLimitMs: 1000,
    exactEndgameEmpties: 8,
    aspirationWindow: 40,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.ok(etcActivityResult.stats.etcNodes > 0, 'Iterative deepening should activate ETC on at least some root-adjacent or late regression nodes.');
  assert.ok(etcActivityResult.stats.etcChildTableHits > 0, 'The ETC activity regression should find child TT entries generated earlier in the search.');
  assert.ok(etcActivityResult.stats.etcExactNodes > 0, 'Depth-limited / exact ETC activity should be counted in the exact ETC bucket.');
  assert.equal(etcActivityResult.stats.etcWldNodes, 0, 'Ordinary negamax regressions should not increment the WLD ETC bucket.');

  const etcDisabledOptionsEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 200,
    randomness: 0,
    enhancedTranspositionCutoff: false,
  });
  assert.equal(etcDisabledOptionsEngine.options.enhancedTranspositionCutoff, false, 'Explicit ETC disabling should survive option resolution for the ordinary negamax path.');
  assert.equal(etcDisabledOptionsEngine.options.enhancedTranspositionCutoffWld, false, 'When no separate WLD ETC override is given, disabling ETC should also disable the WLD ETC path.');

  const sizeBeforeUpdate = engine.transpositionTable.size;
  engine.updateOptions({
    presetKey: engine.options.presetKey,
    styleKey: engine.options.styleKey,
    maxDepth: engine.options.maxDepth,
    timeLimitMs: engine.options.timeLimitMs,
    exactEndgameEmpties: engine.options.exactEndgameEmpties,
    aspirationWindow: engine.options.aspirationWindow,
    randomness: engine.options.randomness,
  });
  assert.equal(engine.transpositionTable.size, sizeBeforeUpdate, 'Updating with equivalent options should preserve the transposition table.');

  engine.updateOptions({
    presetKey: 'custom',
    maxDepth: 5,
    timeLimitMs: 500,
    exactEndgameEmpties: engine.options.exactEndgameEmpties,
    aspirationWindow: engine.options.aspirationWindow,
    randomness: 0,
    styleKey: 'aggressive',
  });
  assert.equal(engine.transpositionTable.size, sizeBeforeUpdate, 'Style changes should be ignored while custom difficulty is active.');

  engine.updateOptions({
    presetKey: 'custom',
    maxDepth: 5,
    timeLimitMs: 500,
    exactEndgameEmpties: engine.options.exactEndgameEmpties,
    aspirationWindow: engine.options.aspirationWindow,
    randomness: 0,
    wldPreExactEmpties: 2,
  });
  assert.equal(engine.transpositionTable.size, 0, 'Changing the explicit WLD pre-exact window should clear the transposition table because root search semantics changed.');

  const forcedPass = playDeterministicPly(GameState.initial(), 18);
  const passResult = engine.findBestMove(forcedPass, { presetKey: 'custom', timeLimitMs: 500, maxDepth: 5, styleKey: 'balanced' });
  assert.equal(passResult.didPass, true);
  assert.equal(passResult.bestMoveIndex, null);
  const passChild = engine.negamax(forcedPass.passTurn(), Math.max(0, passResult.stats.completedDepth - 1), -1e9, 1e9, 1);
  assert.equal(
    passResult.score,
    -passChild.score,
    'Root pass handling should report the searched score instead of a hard-coded zero.',
  );

  const cachedPassLine = engine.negamax(forcedPass, 4, -1e9, 1e9, 0);
  const cachedPassEntry = engine.lookupTransposition(forcedPass);
  assert.ok(
    cachedPassEntry,
    'Pass nodes should now be cached in the transposition table for reuse.',
  );
  assert.equal(
    cachedPassEntry.bestMoveIndex,
    null,
    'Pass-node table entries should keep a null move marker.',
  );
  assert.equal(
    cachedPassEntry.value,
    cachedPassLine.score,
    'Cached pass-node values should match the searched negamax result.',
  );

  const subtreeExactBoundaryState = createStateFromMoveSequence(
    'F5 F6 E6 D6 C5 E3 E7 C7 D3 F4 D7 D8 F8 C8 F3 C6 G4 E8 B8 C4 B6 B4 A3 C3 D2 B5 F7 B3 A6 A4 A5 E2 D1 C1 B1 E1 F1 F2 G1 C2 A2 G6 G5',
  );
  assert.equal(
    subtreeExactBoundaryState.currentPlayer,
    'white',
    'The subtree exact-boundary regression setup should hand the move to white.',
  );
  assert.equal(
    subtreeExactBoundaryState.getEmptyCount(),
    17,
    'The subtree exact-boundary regression setup should sit one ply above the configured exact window.',
  );
  const subtreeExactBoundaryEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 1,
    timeLimitMs: 1000,
    exactEndgameEmpties: 16,
    aspirationWindow: 0,
    randomness: 0,
  });
  subtreeExactBoundaryEngine.solveSmallExact = () => {
    throw new Error('The exact small-solver must stay disabled while the root is still above the exact boundary.');
  };
  const subtreeExactBoundaryResult = subtreeExactBoundaryEngine.findBestMove(subtreeExactBoundaryState, {
    presetKey: 'custom',
    maxDepth: 1,
    timeLimitMs: 1000,
    exactEndgameEmpties: 16,
    aspirationWindow: 0,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.equal(
    subtreeExactBoundaryResult.stats.completedDepth,
    1,
    'A one-ply search one empty above the exact boundary should still complete normally.',
  );
  assert.ok(
    Number.isFinite(subtreeExactBoundaryResult.score),
    'Root positions above the exact boundary should never fall back to the internal ±infinity sentinel.',
  );

  const fallbackOnlyEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 500,
    exactEndgameEmpties: 8,
    aspirationWindow: 40,
    randomness: 0,
  });
  fallbackOnlyEngine.runIterativeDeepening = () => null;
  const fallbackOnlyResult = fallbackOnlyEngine.findBestMove(midgame, {
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 500,
    exactEndgameEmpties: 8,
    aspirationWindow: 40,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.ok(
    Number.isFinite(fallbackOnlyResult.score),
    'Search fallback results should report a bounded heuristic score instead of the internal ±infinity sentinel.',
  );
  assert.ok(
    fallbackOnlyResult.analyzedMoves.length > 0,
    'Search fallback results should still expose scored candidate moves.',
  );
  assert.ok(
    fallbackOnlyResult.analyzedMoves.every((move) => Number.isFinite(move.score)),
    'Fallback candidate scores should stay finite so the UI never announces sentinel values.',
  );

  const nearEndgame = playDeterministicallyUntilEmptyCount(GameState.initial(), 4);
  assert.equal(nearEndgame.getEmptyCount(), 4, 'Small endgame regression setup should reach four empties.');
  const exactScore = bruteForceExactScore(nearEndgame);
  const nearEndgameResult = engine.findBestMove(nearEndgame, {
    presetKey: 'custom',
    timeLimitMs: 1200,
    maxDepth: 4,
    exactEndgameEmpties: 16,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.equal(
    nearEndgameResult.score,
    exactScore,
    'The near-terminal specialized solver should preserve the exact endgame score.',
  );
  assert.ok(
    nearEndgameResult.stats.smallSolverCalls > 0,
    'Near-terminal exact search should route through the specialized small-endgame solver.',
  );

  const exactOneShotEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 16,
    randomness: 0,
  });
  exactOneShotEngine.runIterativeDeepening = () => {
    throw new Error('Exact-root searches should bypass iterative deepening and use a single direct solve.');
  };
  const exactOneShotResult = exactOneShotEngine.findBestMove(nearEndgame, {
    presetKey: 'custom',
    timeLimitMs: 1200,
    maxDepth: 4,
    exactEndgameEmpties: 16,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.equal(
    exactOneShotResult.searchMode,
    'exact-endgame',
    'Exact-root results should expose an explicit exact-endgame search mode for the UI.',
  );
  assert.equal(
    exactOneShotResult.isExactResult,
    true,
    'Completed exact-root searches should mark their reported score as exact.',
  );
  assert.match(
    formatSearchSummary(exactOneShotResult),
    /정확 끝내기/,
    'The UI search summary should explicitly label exact-root searches as exact endgames.',
  );

  const exactPartialTimeoutSetup = findExactRootTimeoutRegressionState();
  assert.ok(
    exactPartialTimeoutSetup,
    'The timeout regression should find an exact-root position where the first solved move differs from the heuristic fallback.',
  );
  const exactPartialTimeoutEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 16,
    aspirationWindow: 0,
    randomness: 0,
  });
  const timeoutError = captureSearchTimeoutErrorInstance(exactPartialTimeoutEngine);
  let negamaxCalls = 0;
  exactPartialTimeoutEngine.negamax = () => {
    negamaxCalls += 1;
    if (negamaxCalls === 1) {
      return {
        score: -3200,
        principalVariation: [],
      };
    }
    throw timeoutError;
  };
  const exactPartialTimeoutResult = exactPartialTimeoutEngine.findBestMove(exactPartialTimeoutSetup.state, {
    presetKey: 'custom',
    timeLimitMs: 1200,
    maxDepth: 4,
    exactEndgameEmpties: 16,
    aspirationWindow: 0,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.equal(
    exactPartialTimeoutResult.searchMode,
    'exact-endgame',
    'Timed-out exact-root searches should keep the exact-endgame mode marker.',
  );
  assert.equal(
    exactPartialTimeoutResult.searchCompletion,
    'partial-timeout',
    'Timed-out exact-root searches should expose that a partial exact result survived the timeout.',
  );
  assert.equal(
    exactPartialTimeoutResult.isExactResult,
    false,
    'A timed-out exact-root search must not claim that the exact solve finished.',
  );
  assert.equal(
    exactPartialTimeoutResult.bestMoveIndex,
    exactPartialTimeoutSetup.firstOrderedMove.index,
    'When exact-root search times out after finishing at least one move, the engine should keep the best completed root move.',
  );
  assert.notEqual(
    exactPartialTimeoutResult.bestMoveIndex,
    exactPartialTimeoutSetup.fallback.bestMoveIndex,
    'The timeout survivor should come from the exact root-search progress rather than the one-ply heuristic fallback.',
  );
  assert.equal(
    exactPartialTimeoutResult.analyzedMoves.length,
    1,
    'Only fully completed root moves should appear in the partial exact-timeout report.',
  );
  assert.match(
    formatSearchSummary(exactPartialTimeoutResult),
    /시간 만료로 현재까지 최선 수 반환/,
    'The UI summary should distinguish preserved partial exact results from pure heuristic fallback.',
  );

  const exactFallbackEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 16,
    randomness: 0,
  });
  exactFallbackEngine.runSingleDepthSearch = () => null;
  const exactFallbackResult = exactFallbackEngine.findBestMove(nearEndgame, {
    presetKey: 'custom',
    timeLimitMs: 1200,
    maxDepth: 4,
    exactEndgameEmpties: 16,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.equal(
    exactFallbackResult.searchMode,
    'exact-endgame',
    'Exact-root fallback results should preserve the exact-endgame mode marker.',
  );
  assert.equal(
    exactFallbackResult.isExactResult,
    false,
    'Fallback results should not claim that an exact solve finished.',
  );
  assert.match(
    formatSearchSummary(exactFallbackResult),
    /정확 끝내기 미완료/,
    'The UI summary should distinguish incomplete exact-root attempts from finished exact solves.',
  );

  const wldPreExactState = findSeededStateWithMinimumLegalMoves(5, 2);
  assert.ok(
    wldPreExactState,
    'The WLD regression should find a five-empty position with at least two legal root moves.',
  );
  const wldDepthLimitedState = findSeededStateWithMinimumLegalMoves(6, 2);
  assert.ok(
    wldDepthLimitedState,
    'The WLD regression should find a six-empty position outside the pre-exact window.',
  );

  const wldReferenceOutcome = classifyOutcomeFromScore(bruteForceExactScore(wldPreExactState));
  const wldEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 1,
  });
  wldEngine.runIterativeDeepening = () => {
    throw new Error('WLD pre-exact roots should bypass iterative deepening and run a dedicated single-pass WLD solve.');
  };
  wldEngine.negamax = () => {
    throw new Error('WLD pre-exact roots should not fall back to the depth-limited/exact negamax path.');
  };
  wldEngine.solveSmallExact = () => {
    throw new Error('WLD pre-exact roots should keep their own WLD-only small solver instead of using the exact small solver.');
  };
  const wldResult = wldEngine.findBestMove(wldPreExactState, {
    presetKey: 'custom',
    timeLimitMs: 1200,
    maxDepth: 4,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 1,
    styleKey: 'balanced',
  });
  assert.equal(
    wldResult.searchMode,
    'wld-endgame',
    'Roots exactly one empty above the exact boundary should expose a dedicated WLD endgame search mode.',
  );
  assert.equal(
    wldResult.isWldResult,
    true,
    'Completed WLD pre-exact searches should mark that a full WLD solve finished.',
  );
  assert.equal(
    classifyOutcomeFromScore(wldResult.score),
    wldReferenceOutcome,
    'The dedicated WLD solve should preserve the exact win/draw/loss outcome on a small pre-exact regression state.',
  );
  assert.ok(
    wldResult.stats.wldNodes > 0,
    'The dedicated WLD mode should report that it expanded WLD nodes.',
  );
  assert.ok(
    wldResult.stats.wldSmallSolverCalls > 0,
    'The dedicated WLD mode should route late leaves through the WLD-only small solver.',
  );
  assert.match(
    formatSearchSummary(wldResult),
    /승무패 끝내기/,
    'The UI summary should explicitly label completed WLD pre-exact solves.',
  );

  const exactAgainstWldEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 1,
  });
  exactAgainstWldEngine.wldNegamax = () => {
    throw new Error('Exact-root positions must not route through the WLD solver.');
  };
  const exactAgainstWldResult = exactAgainstWldEngine.findBestMove(nearEndgame, {
    presetKey: 'custom',
    timeLimitMs: 1200,
    maxDepth: 4,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 1,
    styleKey: 'balanced',
  });
  assert.equal(
    exactAgainstWldResult.searchMode,
    'exact-endgame',
    'Positions inside the exact boundary should stay on the exact solver even when WLD pre-exact mode is enabled.',
  );

  const depthLimitedAgainstWldEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 3,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 1,
  });
  depthLimitedAgainstWldEngine.wldNegamax = () => {
    throw new Error('Positions outside the pre-exact window must stay on the normal depth-limited search.');
  };
  const depthLimitedAgainstWldResult = depthLimitedAgainstWldEngine.findBestMove(wldDepthLimitedState, {
    presetKey: 'custom',
    timeLimitMs: 1200,
    maxDepth: 3,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 1,
    styleKey: 'balanced',
  });
  assert.equal(
    depthLimitedAgainstWldResult.searchMode,
    'depth-limited',
    'Positions beyond the configured pre-exact window should keep the ordinary depth-limited search mode.',
  );

  assert.equal(
    wldDepthLimitedState.currentPlayer,
    'black',
    'The two-empty-above pre-exact regression should cover the black-to-move parity case that the +1 window misses.',
  );

  const wldRangeTwoReferenceOutcome = classifyOutcomeFromScore(bruteForceExactScore(wldDepthLimitedState));
  const blackWldRangeTwoEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 2,
  });
  blackWldRangeTwoEngine.runIterativeDeepening = () => {
    throw new Error('Two-empty-above pre-exact WLD roots should still bypass iterative deepening and stay in the dedicated WLD solver.');
  };
  blackWldRangeTwoEngine.negamax = () => {
    throw new Error('Two-empty-above pre-exact WLD roots should not fall back to the mixed depth-limited/exact negamax path.');
  };
  blackWldRangeTwoEngine.solveSmallExact = () => {
    throw new Error('Two-empty-above pre-exact WLD roots should keep using the WLD-only late solver.');
  };
  const blackWldRangeTwoResult = blackWldRangeTwoEngine.findBestMove(wldDepthLimitedState, {
    presetKey: 'custom',
    timeLimitMs: 1200,
    maxDepth: 4,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 2,
    styleKey: 'balanced',
  });
  assert.equal(
    blackWldRangeTwoResult.searchMode,
    'wld-endgame',
    'Roots exactly two empties above the exact boundary should also expose the dedicated WLD endgame mode when +2 is enabled.',
  );
  assert.equal(
    blackWldRangeTwoResult.isWldResult,
    true,
    'Completed +2 pre-exact WLD searches should still report a finished WLD solve.',
  );
  assert.equal(
    classifyOutcomeFromScore(blackWldRangeTwoResult.score),
    wldRangeTwoReferenceOutcome,
    'The black-side +2 WLD solve should preserve the exact win/draw/loss outcome on a small regression state.',
  );

  const wldEtcWindowMoves = wldDepthLimitedState.getSearchMoves();
  assert.ok(wldEtcWindowMoves.length >= 2, 'The WLD ETC regression should expose at least two legal moves in the +2 pre-exact window.');

  const wldEtcEnabledEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 2,
    enhancedTranspositionCutoffWld: true,
  });
  const wldEtcFailHighChild = wldDepthLimitedState.applyMoveFast(
    wldEtcWindowMoves[0].index,
    wldEtcWindowMoves[0].flips ?? null,
  );
  assert.ok(wldEtcFailHighChild, 'The WLD ETC fail-high regression child should be legal.');
  wldEtcEnabledEngine.storeTransposition(wldEtcFailHighChild, {
    depth: wldDepthLimitedState.getEmptyCount(),
    value: -10000,
    flag: 'upper',
    bestMoveIndex: null,
  });
  const wldEtcFailHigh = wldEtcEnabledEngine.applyEnhancedTranspositionCutoff(
    wldDepthLimitedState,
    wldEtcWindowMoves,
    wldDepthLimitedState.getEmptyCount() + 1,
    -10000,
    10000,
    1,
    true,
    'wld',
  );
  assert.ok(wldEtcFailHigh, 'The WLD ETC helper should activate on pre-exact WLD nodes when enabled.');
  assert.equal(wldEtcFailHigh.cutoff, true, 'A proven WLD child upper-bound should allow a fail-high ETC cutoff in the WLD bucket.');
  assert.equal(wldEtcFailHigh.score, 10000, 'The WLD ETC cutoff should negate the child bound into a parent win bound.');
  assert.ok(wldEtcEnabledEngine.stats.etcWldNodes > 0, 'The WLD ETC helper should increment the dedicated WLD ETC bucket counters.');
  assert.equal(wldEtcEnabledEngine.stats.etcExactNodes, 0, 'The WLD ETC helper should not touch the ordinary exact ETC bucket counters.');

  const wldEtcDisabledEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    wldPreExactEmpties: 2,
    enhancedTranspositionCutoffWld: false,
  });
  wldEtcDisabledEngine.storeTransposition(wldEtcFailHighChild, {
    depth: wldDepthLimitedState.getEmptyCount(),
    value: -10000,
    flag: 'upper',
    bestMoveIndex: null,
  });
  const wldEtcDisabled = wldEtcDisabledEngine.applyEnhancedTranspositionCutoff(
    wldDepthLimitedState,
    wldEtcWindowMoves,
    wldDepthLimitedState.getEmptyCount() + 1,
    -10000,
    10000,
    1,
    true,
    'wld',
  );
  assert.equal(wldEtcDisabled, null, 'Disabling WLD ETC should skip the helper entirely for WLD nodes.');
  assert.equal(wldEtcDisabledEngine.stats.etcWldNodes, 0, 'Disabling WLD ETC should keep the dedicated WLD bucket counters at zero.');

  assert.equal(
    new SearchEngine({ presetKey: 'hard' }).options.wldPreExactEmpties,
    0,
    'Hard and shallower presets should keep WLD pre-exact mode disabled by default.',
  );
  assert.equal(
    new SearchEngine({ presetKey: 'expert' }).options.wldPreExactEmpties,
    0,
    'Expert strength should now keep WLD pre-exact mode disabled unless it is explicitly enabled.',
  );
  assert.equal(
    new SearchEngine({ presetKey: 'impossible' }).options.wldPreExactEmpties,
    0,
    'Impossible strength should now keep WLD pre-exact mode disabled unless it is explicitly enabled.',
  );
  assert.equal(
    new SearchEngine({
      presetKey: 'custom',
      maxDepth: 8,
      timeLimitMs: 3900,
      exactEndgameEmpties: 12,
      aspirationWindow: 0,
      randomness: 0,
    }).options.wldPreExactEmpties,
    0,
    'Strong custom settings should keep WLD pre-exact mode disabled by default until the user selects +2.',
  );
  assert.equal(
    new SearchEngine({
      presetKey: 'custom',
      maxDepth: 8,
      timeLimitMs: 3900,
      exactEndgameEmpties: 12,
      aspirationWindow: 0,
      randomness: 0,
      wldPreExactEmpties: 2,
    }).options.wldPreExactEmpties,
    2,
    'Explicit custom WLD pre-exact input should still enable the +2 window.',
  );

  assert.equal(
    nearEndgameResult.stats.lmrReductions,
    0,
    'Late-move reduction should stay disabled inside exact endgame search.',
  );

  const tinyOrderingProbe = playSeededRandomUntilEmptyCount(8, 6);
  assert.equal(tinyOrderingProbe.getEmptyCount(), 8, 'Tiny late-game regression setup should reach eight empties.');
  const tinyOrderingResult = engine.findBestMove(tinyOrderingProbe, {
    presetKey: 'custom',
    timeLimitMs: 1800,
    maxDepth: 4,
    exactEndgameEmpties: 16,
    randomness: 0,
    styleKey: 'balanced',
  });
  assert.equal(
    tinyOrderingResult.stats.orderingEvalCalls,
    0,
    'The lightweight move-ordering evaluator should stay disabled once the endgame is already tiny enough for direct tactical heuristics to dominate.',
  );

  const stabilityBoundRegressionStates = [
    createStateFromBitboards({
      black: 17910994675932133648n,
      white: 517734999267935876n,
      currentPlayer: 'black',
    }),
    createStateFromBitboards({
      black: 18059068105867983120n,
      white: 81431193180374660n,
      currentPlayer: 'white',
    }),
    createStateFromBitboards({
      black: 18059068105859545360n,
      white: 81431193188779652n,
      currentPlayer: 'black',
    }),
  ];

  for (const stabilityState of stabilityBoundRegressionStates) {
    const empties = stabilityState.getEmptyCount();
    const { player, opponent } = stabilityState.getPlayerBoards();
    const stableBounds = describeStableDiscBounds(player, opponent, empties);
    const exactScore = bruteForceExactScore(stabilityState);
    assert.ok(
      exactScore >= (stableBounds.lowerBound * 10000) && exactScore <= (stableBounds.upperBound * 10000),
      `Stable-disc bounds should conservatively contain the exact score at ${empties} empties.`,
    );
  }

  for (const seed of [1, 2, 3]) {
    const seededNearEndgame = playSeededRandomUntilEmptyCount(6, seed);
    assert.equal(seededNearEndgame.getEmptyCount(), 6, `Seeded endgame regression ${seed} should reach six empties.`);
    const seededExactScore = bruteForceExactScore(seededNearEndgame);
    const seededResult = engine.findBestMove(seededNearEndgame, {
      presetKey: 'custom',
      timeLimitMs: 1800,
      maxDepth: 4,
      exactEndgameEmpties: 16,
      randomness: 0,
      styleKey: 'balanced',
    });
    assert.equal(
      seededResult.score,
      seededExactScore,
      `Exact endgame search should match brute force on seeded regression position ${seed}.`,
    );
  }

  const fewEmptiesDirectRegression = playSeededRandomUntilEmptyCount(4, 2);
  assert.equal(fewEmptiesDirectRegression.getEmptyCount(), 4, 'The Stage 22 few-empties direct regression should reach four empties.');
  const fewEmptiesDirectReference = bruteForceExactScore(fewEmptiesDirectRegression);

  const fewEmptiesBaselineEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    optimizedFewEmptiesExactSolver: false,
  });
  const fewEmptiesBaselineScore = fewEmptiesBaselineEngine.solveSmallExact(fewEmptiesDirectRegression);

  const fewEmptiesOptimizedEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    optimizedFewEmptiesExactSolver: true,
  });
  const fewEmptiesOptimizedScore = fewEmptiesOptimizedEngine.solveSmallExact(fewEmptiesDirectRegression);

  assert.equal(fewEmptiesBaselineScore, fewEmptiesDirectReference, 'The full-width few-empties exact solver baseline should still match brute force.');
  assert.equal(fewEmptiesOptimizedScore, fewEmptiesDirectReference, 'The Stage 22 optimized few-empties exact solver should preserve the exact score.');
  assert.ok(
    fewEmptiesOptimizedEngine.stats.smallSolverNodes <= fewEmptiesBaselineEngine.stats.smallSolverNodes,
    'The optimized few-empties exact solver should not visit more small-solver nodes than the full-width baseline on the direct regression.',
  );

  const fewEmptiesBoundaryRegression = playSeededRandomUntilEmptyCount(10, 45);
  assert.equal(fewEmptiesBoundaryRegression.getEmptyCount(), 10, 'The Stage 22 few-empties boundary regression should reach ten empties.');

  const fewEmptiesBoundaryBaseline = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 6000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 0,
    optimizedFewEmptiesExactSolver: false,
  }).findBestMove(fewEmptiesBoundaryRegression);

  const fewEmptiesBoundaryOptimized = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 6000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 0,
    optimizedFewEmptiesExactSolver: true,
  }).findBestMove(fewEmptiesBoundaryRegression);

  assert.equal(fewEmptiesBoundaryOptimized.searchMode, 'exact-endgame', 'The Stage 22 optimized few-empties solver should only engage inside the exact bucket.');
  assert.equal(fewEmptiesBoundaryOptimized.bestMoveCoord, fewEmptiesBoundaryBaseline.bestMoveCoord, 'The Stage 22 optimized few-empties solver should preserve the root exact best move on the boundary regression.');
  assert.equal(fewEmptiesBoundaryOptimized.score, fewEmptiesBoundaryBaseline.score, 'The Stage 22 optimized few-empties solver should preserve the root exact score on the boundary regression.');
  assert.ok(
    fewEmptiesBoundaryOptimized.stats.smallSolverNodes < fewEmptiesBoundaryBaseline.stats.smallSolverNodes,
    'The Stage 22 optimized few-empties solver should reduce small-solver work on the exact boundary regression.',
  );

  const fewEmptiesWldRegression = playSeededRandomUntilEmptyCount(12, 50);
  assert.equal(fewEmptiesWldRegression.getEmptyCount(), 12, 'The Stage 22 few-empties WLD regression should reach twelve empties.');

  const fewEmptiesWldBaseline = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 8,
    timeLimitMs: 3000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 2,
    optimizedFewEmptiesExactSolver: false,
  }).findBestMove(fewEmptiesWldRegression);

  const fewEmptiesWldOptimized = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 8,
    timeLimitMs: 3000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 2,
    optimizedFewEmptiesExactSolver: true,
  }).findBestMove(fewEmptiesWldRegression);

  assert.equal(fewEmptiesWldBaseline.searchMode, 'wld-endgame', 'The Stage 22 WLD regression should stay inside the dedicated WLD bucket.');
  assert.equal(fewEmptiesWldOptimized.bestMoveCoord, fewEmptiesWldBaseline.bestMoveCoord, 'The exact-only few-empties optimization should not change WLD root move choice on the WLD regression.');
  assert.equal(fewEmptiesWldOptimized.score, fewEmptiesWldBaseline.score, 'The exact-only few-empties optimization should not change WLD root score on the WLD regression.');
  assert.equal(fewEmptiesWldOptimized.stats.wldSmallSolverNodes, fewEmptiesWldBaseline.stats.wldSmallSolverNodes, 'The exact-only few-empties optimization should leave the WLD small solver untouched.');

  const specializedFewEmptiesBaselineEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    optimizedFewEmptiesExactSolver: true,
    specializedFewEmptiesExactSolver: false,
  });
  const specializedFewEmptiesCandidateEngine = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 1200,
    exactEndgameEmpties: 4,
    randomness: 0,
    optimizedFewEmptiesExactSolver: true,
    specializedFewEmptiesExactSolver: true,
  });
  const specializedFewEmptiesBaselineScore = specializedFewEmptiesBaselineEngine.solveSmallExact(fewEmptiesDirectRegression);
  const specializedFewEmptiesCandidateScore = specializedFewEmptiesCandidateEngine.solveSmallExact(fewEmptiesDirectRegression);

  assert.equal(specializedFewEmptiesBaselineScore, fewEmptiesDirectReference, 'The Stage 23 baseline should preserve the direct four-empty exact score.');
  assert.equal(specializedFewEmptiesCandidateScore, fewEmptiesDirectReference, 'The Stage 23 specialized few-empties solver should preserve the direct four-empty exact score.');
  assert.ok(
    specializedFewEmptiesCandidateEngine.stats.specializedFewEmpties4Calls > 0,
    'The Stage 23 specialized few-empties regression should actually dispatch through the dedicated four-empty solver.',
  );
  assert.ok(
    specializedFewEmptiesCandidateEngine.stats.smallSolverNodes < specializedFewEmptiesBaselineEngine.stats.smallSolverNodes,
    'The Stage 23 specialized few-empties direct regression should reduce exact small-solver work versus the Stage 22 path.',
  );

  const specializedBoundaryBaseline = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 6000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 0,
    optimizedFewEmptiesExactSolver: true,
    specializedFewEmptiesExactSolver: false,
  }).findBestMove(fewEmptiesBoundaryRegression);

  const specializedBoundaryCandidate = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 6000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 0,
    optimizedFewEmptiesExactSolver: true,
    specializedFewEmptiesExactSolver: true,
  }).findBestMove(fewEmptiesBoundaryRegression);

  assert.equal(specializedBoundaryCandidate.searchMode, 'exact-endgame', 'The Stage 23 specialized few-empties solver should stay inside the exact bucket.');
  assert.equal(specializedBoundaryCandidate.bestMoveCoord, specializedBoundaryBaseline.bestMoveCoord, 'The Stage 23 specialized few-empties solver should preserve the exact best move on the boundary regression.');
  assert.equal(specializedBoundaryCandidate.score, specializedBoundaryBaseline.score, 'The Stage 23 specialized few-empties solver should preserve the exact score on the boundary regression.');
  assert.ok(
    specializedBoundaryCandidate.stats.specializedFewEmptiesCalls > 0,
    'The Stage 23 boundary regression should visit the dedicated specialized exact solver.',
  );
  assert.ok(
    specializedBoundaryCandidate.stats.smallSolverNodes < specializedBoundaryBaseline.stats.smallSolverNodes,
    'The Stage 23 specialized few-empties solver should reduce exact small-solver work on the boundary regression.',
  );

  const specializedWldBaseline = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 8,
    timeLimitMs: 3000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 2,
    optimizedFewEmptiesExactSolver: true,
    specializedFewEmptiesExactSolver: false,
  }).findBestMove(fewEmptiesWldRegression);

  const specializedWldCandidate = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 8,
    timeLimitMs: 3000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 2,
    optimizedFewEmptiesExactSolver: true,
    specializedFewEmptiesExactSolver: true,
  }).findBestMove(fewEmptiesWldRegression);

  assert.equal(specializedWldCandidate.bestMoveCoord, specializedWldBaseline.bestMoveCoord, 'The Stage 23 specialized few-empties solver should not change WLD root move choice.');
  assert.equal(specializedWldCandidate.score, specializedWldBaseline.score, 'The Stage 23 specialized few-empties solver should not change WLD root score.');
  assert.equal(specializedWldCandidate.stats.wldSmallSolverNodes, specializedWldBaseline.stats.wldSmallSolverNodes, 'The Stage 23 specialized few-empties solver should leave the WLD small solver untouched.');
  assert.equal(specializedWldCandidate.stats.specializedFewEmptiesCalls, 0, 'The Stage 23 specialized few-empties solver should not run inside the WLD bucket.');

  const exactFastestRegression = playSeededRandomUntilEmptyCount(14, 23);
  assert.equal(exactFastestRegression.getEmptyCount(), 14, 'The Stage 24 exact fastest-first regression should reach fourteen empties.');

  const exactFastestBaseline = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 15000,
    exactEndgameEmpties: 14,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 0,
    maxTableEntries: 400000,
    exactFastestFirstOrdering: false,
  }).findBestMove(exactFastestRegression);

  const exactFastestCandidate = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 4,
    timeLimitMs: 15000,
    exactEndgameEmpties: 14,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 0,
    maxTableEntries: 400000,
  }).findBestMove(exactFastestRegression);

  assert.equal(exactFastestCandidate.searchMode, 'exact-endgame', 'The Stage 24 fastest-first candidate should stay inside the exact bucket.');
  assert.equal(exactFastestCandidate.bestMoveCoord, exactFastestBaseline.bestMoveCoord, 'The Stage 24 fastest-first candidate should preserve the exact best move on the 14-empty regression.');
  assert.equal(exactFastestCandidate.score, exactFastestBaseline.score, 'The Stage 24 fastest-first candidate should preserve the exact score on the 14-empty regression.');
  assert.ok(
    exactFastestCandidate.stats.fastestFirstExactSorts > 0,
    'The Stage 24 fastest-first regression should actually trigger exact fastest-first ordering.',
  );
  assert.ok(
    exactFastestCandidate.stats.nodes < exactFastestBaseline.stats.nodes,
    'The Stage 24 fastest-first candidate should reduce exact node count on the 14-empty regression.',
  );



  const exactFastestWldCandidate = new SearchEngine({
    presetKey: 'custom',
    maxDepth: 8,
    timeLimitMs: 3000,
    exactEndgameEmpties: 10,
    aspirationWindow: 0,
    randomness: 0,
    wldPreExactEmpties: 2,
    exactFastestFirstOrdering: true,
  }).findBestMove(fewEmptiesWldRegression);

  assert.equal(exactFastestWldCandidate.bestMoveCoord, fewEmptiesWldBaseline.bestMoveCoord, 'The Stage 24 exact fastest-first ordering should not change WLD root move choice.');
  assert.equal(exactFastestWldCandidate.score, fewEmptiesWldBaseline.score, 'The Stage 24 exact fastest-first ordering should not change WLD root score.');
  assert.equal(exactFastestWldCandidate.stats.fastestFirstExactSorts, 0, 'The Stage 24 exact fastest-first ordering should stay inactive inside the WLD bucket.');
}

function run() {
  runCoreRuleTests();
  runEvaluatorTests();
  runOpeningBookTests();
  runPresetResolutionTests();
  runSearchTests();
  console.log('core-smoke: all assertions passed');
}

run();
